# Java FS - Gen AI Empowered Engineer Training (TRNG-00001985)

## Timings

### Morning Session - 8:30 AM to 12:45 PM

- **Lecture / Guided Coding Example:**  2hrs
- **Coding Activity / Coding Challenge:** 2hrs
- **Morning Break:** 10:30 AM to 10:45 AM

### Lunch 12:45 PM to 1:30 PM

### Afternoon Session - 1:30 PM to 5:30 PM

- **Lecture / Guided Coding Example:** 1hr 45 min
- **Coding Activity / Coding Challenge:** 2hrs
- **Afternoon Break:** 3:15 PM to 3:30 pM



