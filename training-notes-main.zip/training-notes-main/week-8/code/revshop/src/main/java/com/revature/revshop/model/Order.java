package com.revature.revshop.model;

public class Order {

}
