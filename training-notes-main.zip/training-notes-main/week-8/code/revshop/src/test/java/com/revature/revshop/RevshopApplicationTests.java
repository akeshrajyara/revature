package com.revature.revshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RevshopApplicationTests {

	@Test
	void contextLoads() {
	}

}
