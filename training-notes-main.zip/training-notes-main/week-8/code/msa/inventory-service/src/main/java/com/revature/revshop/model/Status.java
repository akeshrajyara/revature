package com.revature.revshop.model;

public enum Status {
	
	AVAILABLE, OUT_OF_STOCK, DISCONTINUED

}
