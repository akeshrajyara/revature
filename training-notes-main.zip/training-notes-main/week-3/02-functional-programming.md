# Lecture/Guided Coding Example Plan

1. Functional Programing
   - Lambdas
   - Functional Interfaces

---


# Functional Programming

## Local Class

- classes defined in a block.
- commonly defined in body of a method.

## Anonymous class

- anonymous classes allow decalreation and instantiation of a class at same time.
- local classes without a name.

## functional Interface

- an interface with one abstract method.

## Lambda

- a consise wat to represent a functional interface


```java
(parameter list) -> expression
```