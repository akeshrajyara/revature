# Lecture/ Guided coding example

1. Spring with JSP


---

1. add dependencies
2. configiration

```
spring.mvc.view.prefix=/WEB-INF/view/
spring.mvc.view.suffix=.jsp
```