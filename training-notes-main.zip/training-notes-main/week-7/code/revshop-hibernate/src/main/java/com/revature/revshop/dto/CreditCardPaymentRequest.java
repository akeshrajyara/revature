package com.revature.revshop.dto;

public class CreditCardPaymentRequest {

}
