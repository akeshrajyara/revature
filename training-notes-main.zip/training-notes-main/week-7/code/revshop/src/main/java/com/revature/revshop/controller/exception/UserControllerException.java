package com.revature.revshop.controller.exception;

public class UserControllerException extends Exception{
	
	public UserControllerException(String message) {
		super(message);
	}

}
