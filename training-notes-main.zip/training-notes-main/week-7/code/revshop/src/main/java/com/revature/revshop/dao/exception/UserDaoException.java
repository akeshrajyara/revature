package com.revature.revshop.dao.exception;

public class UserDaoException extends Exception{

	public UserDaoException(String message) {
		
		super(message);
		// TODO Auto-generated constructor stub
	}

}
