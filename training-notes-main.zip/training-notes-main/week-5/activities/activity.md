#### JS Activity

a web page that fetches product data from an API and displays it on the page.

**requirements**

1. HTML page to display products
2. JavaScript code to fetch product data from JSON Server
3. CSS to style the page
4. JS DOM manipulation to display the content 


---

2. Interactive Clock and Alarm using setInterval() and setTimeout()




