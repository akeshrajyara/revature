package entity;

public class User {
	private int id;
	private String name;
	private transient String passsord;

}
