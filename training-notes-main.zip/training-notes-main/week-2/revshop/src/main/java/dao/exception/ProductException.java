package dao.exception;

public class ProductException extends Exception{

	public ProductException(String string) {
		// TODO Auto-generated constructor stub
	}

}
