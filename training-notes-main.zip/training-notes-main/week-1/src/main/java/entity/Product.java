package entity;

public class Product {
	
	private int productId = 1;
	private String productName;
	
	private String getProductName() {
		return this.productName;
	}
	
	public int getProductId() {
		
		return this.productId;
		
	}

}
