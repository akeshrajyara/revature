package service.exception;

public class ServiceException extends Exception{
	

}
