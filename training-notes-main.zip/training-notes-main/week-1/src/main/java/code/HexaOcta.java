package code;

public class HexaOcta {
	
	public static void main(String[] args) {
		
		Integer i = 017;
		
		System.out.println(Integer.toHexString(i));
	}

}
