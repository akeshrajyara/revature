package com.revature.revshop.controller;

import org.springframework.stereotype.Controller;

@Controller
public class OrderController {

}
