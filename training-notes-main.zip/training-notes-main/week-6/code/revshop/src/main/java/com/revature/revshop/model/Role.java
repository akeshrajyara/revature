package com.revature.revshop.model;

public enum Role {
	BUYER, SELLER

}
