package dto;

import java.util.List;

public class OrderRequest {
	
	
// creation
	// step 1 order request
	private long userId;
	private float totalAmmount;
	private String createdAt;
	// address
	// payment info
	private List<Long> productIds;
	
	
	// step 2
	
	//insert order
	
	// step 3
	
	// most recent order id
	
	// insert order details for all product ids
	
	//productIds
	
	
	/*
	 * private long userId;
	private float totalAmmount;
	private String createdAt;
	// address
	// payment info
	private String productIds ="1,23,45";
	 * 
	 * 
	 */
	
	
	
	
	

}



