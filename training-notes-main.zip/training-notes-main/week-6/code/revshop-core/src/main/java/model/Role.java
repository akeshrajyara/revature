package model;

public enum Role {
	BUYER, SELLER

}
